Photo Presets Bundle - 100+ Presets
From: digzoom.com

PACKAGE CONTENTS:
================
- 100+ Lightroom Presets (.XMP)
- 50+ Photoshop Actions (.ATN)
- Installation guides for both
- Before/After comparison images
- Video tutorial: How to use presets

COMPATIBILITY:
- Adobe Lightroom CC (Desktop)
- Adobe Lightroom Classic
- Adobe Lightroom Mobile (import via sync)
- Adobe Photoshop CC
- Adobe Camera Raw

PRESET CATEGORIES:
1. Food Photography (20 presets)
2. Portrait Photography (30 presets)
3. Landscape Photography (25 presets)
4. Instagram/Vlog Style (25 presets)

BONUS:
- Mobile DNG presets for Lightroom Mobile
- Adjustment brush presets
- Graduated filter presets

LICENSE:
Commercial Use License
- Use for unlimited photos
- Use for client work
- Resell edited photos with presets applied

TIPS:
- Adjust exposure after applying presets
- Use the "Amount" slider to reduce intensity
- Stack multiple presets for unique looks
- Create your own variations by tweaking settings

SUPPORT: support@digzoom.com
