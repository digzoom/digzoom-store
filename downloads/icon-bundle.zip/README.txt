5000+ Icon Bundle - digzoom

This bundle includes:
- 5000+ icons in SVG, PNG, and EPS formats
- 32 categories: Business, Technology, Social Media, UI, Shopping, etc.
- Multiple styles: Line, Filled, Color, Outline
- Commercial license included

Categories:
1. Business & Finance
2. Technology & Development
3. Social Media & Communication
4. User Interface
5. Shopping & E-Commerce
6. Files & Documents
7. Media & Entertainment
8. Navigation & Maps
9. Weather & Nature
10. Health & Fitness
11. Education & Learning
12. Food & Drink
13. Travel & Transportation
14. Home & Living
15. People & Users
...

License: Commercial Use - Resale Allowed
For support: support@digzoom.com
