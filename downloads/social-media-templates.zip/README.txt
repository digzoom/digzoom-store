Social Media Template Bundle - 200+ Designs
From: digzoom.com

BUNDLE CONTENTS:
================
1. Instagram Post Templates (20 designs)
2. Instagram Story Templates (20 designs)
3. Facebook Post Templates (15 designs)
4. Pinterest Pin Templates (15 designs)
5. YouTube Thumbnail Templates (15 designs)
6. Twitter/X Post Templates (15 designs)
7. LinkedIn Post Templates (10 designs)
8. TikTok Video Cover Templates (10 designs)
9. Social Media Quote Templates (20 designs)
10. Holiday & Seasonal Templates (20 designs)
11. Instagram Highlight Covers (20 icons)
12. Branding Kit (Logo, Colors, Fonts guide)

TOTAL: 200+ templates

FILE FORMATS:
- Adobe Photoshop (.PSD)
- Adobe Illustrator (.AI)
- Canva Links (.txt with URLs)
- PNG Previews

WHAT'S INCLUDED:
- Layered, fully editable files
- Free fonts (Google Fonts links)
- Smart objects for easy image replacement
- Color palette guide
- Video tutorial: How to customize templates

LICENSE:
Commercial Use License
- Use for unlimited personal projects
- Use for unlimited client projects
- Resell as part of a larger product
- Cannot resell templates as-is (modify first)

SUPPORT:
Email: support@digzoom.com
Website: digzoom.com
